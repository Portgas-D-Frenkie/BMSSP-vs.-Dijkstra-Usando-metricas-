# Aporte experimental: 7 métricas BMSSP vs. Dijkstra

Instrumentación propia de 7 métricas (tiempo, correctitud, speedup, memoria
pico, memoria por estructura de datos, tasa de crecimiento empírica y punto de
cruce) sobre la librería oficial de BMSSP, comparada contra Dijkstra clásico.

Proyecto complementario al artículo científico "BMSSP vs. Dijkstra: Análisis
Experimental del Rendimiento del Algoritmo que Rompe la Barrera de Ordenamiento
en Caminos Más Cortos" (UNSAAC, curso de Algoritmos Avanzados).

## Requisitos

- **Compilador C++20**: GCC >= 11 (`g++`) o compatible. Probado con GCC 13.3.0.
- **Python 3.8+** con los paquetes: `numpy`, `matplotlib`, `scipy`
- **Sistema operativo:** Linux o macOS (usa `getrusage()` de POSIX para medir
  memoria pico; no es compatible con Windows nativo tal cual -- en Windows,
  correr dentro de WSL2)

No requiere bibliotecas externas de C++: la librería BMSSP (`single_include/bmssp.hpp`)
ya está incluida en este repositorio y es header-only.

## Instalación

```bash
git clone <URL-de-este-repositorio>
cd <carpeta-del-repositorio>

# Instalar dependencias de Python
pip install numpy matplotlib scipy
```

## Cómo ejecutar (paso a paso)

### 1. Compilar el programa instrumentado

```bash
g++ -std=c++20 -O3 -I. run_one.cpp -o run_one
```

Esto genera el ejecutable `run_one`, que corre UNA instancia (un algoritmo,
un grafo) por invocación, en su propio proceso -- así se puede medir memoria
sin mezclar mediciones entre Dijkstra y BMSSP.

### 2. Correr todos los experimentos

```bash
python3 run_all.py
```

Esto ejecuta las 17 instancias del artículo original (Experimento 1: n=100 a
6400; Experimento 2: n=5000 fijo, m=25000 a 250000), cada una con 10
repeticiones por algoritmo (340 ejecuciones en total). Tarda entre 1 y 2
minutos. Al terminar, genera `results_7metricas.csv` con las 7 métricas.

Verás en consola una línea de progreso por instancia, por ejemplo:
```
[exp1] n=6400 m=64000 seed=8425
   dijkstra=3511.4us  bmssp=12180.1us  speedup=3.47x  correcto=OK
```

### 3. Generar el análisis y las figuras

```bash
python3 analyze.py         # Experimento 1: regresión, punto de cruce, 3 figuras
python3 analyze_exp2.py    # Experimento 2: figura de memoria pico + resumen
```

Esto genera:
- `growth_analysis.txt` -- resultado de la regresión de crecimiento empírico
- `fig_tiempo_exp1.png`, `fig_speedup_exp1.png`, `fig_memoria_estructura_exp1.png`,
  `fig_memoria_pico_exp1.png`, `fig_memoria_pico_exp2.png`

### Verificación rápida (opcional)

Para probar con una sola instancia sin correr todo el lote:
```bash
mkdir -p dist_tmp
./run_one dijkstra 100 1000 2125 1 1000 random 0 20 dist_tmp/d1.txt
./run_one bmssp    100 1000 2125 1 1000 random 0 20 dist_tmp/b1.txt
diff dist_tmp/d1.txt dist_tmp/b1.txt && echo "Distancias idénticas: correcto"
```

## Estructura del repositorio

```
.
├── run_one.cpp                    # Programa instrumentado (C++20)
├── run_all.py                     # Orquestador de los 340 experimentos
├── analyze.py                     # Regresión + figuras (Experimento 1)
├── analyze_exp2.py                # Figura + resumen de memoria (Experimento 2)
├── results_7metricas.csv          # Resultados generados (17 filas x 20 columnas)
├── growth_analysis.txt            # Resultado de la regresión (métricas 6 y 7)
├── fig_*.png                      # Figuras generadas
├── single_include/bmssp.hpp       # Librería oficial de BMSSP (sin modificar)
├── experiments_original.cpp       # Código original del proyecto (solo referencia)
├── snippet_latex.tex              # Sección lista para pegar en el artículo (main.tex)
└── INFORME_APORTE.md              # Metodología y resultados explicados en detalle
```

## Resultados principales (ya generados en results_7metricas.csv)

| Métrica | Resultado |
|---|---|
| Correctitud | 100% OK en las 17 instancias |
| Speedup (BMSSP/Dijkstra) | Converge a 3.47x-4.13x en instancias grandes |
| Memoria pico (RSS) | BMSSP solo +7.5% sobre Dijkstra en el caso más grande |
| Memoria por estructura (heap asignado) | BMSSP usa ~23x más que Dijkstra |
| Tasa de crecimiento | Dijkstra: t~n^1.12 (R2=0.997); BMSSP: t~n^0.86 (R2=0.973) |
| Punto de cruce (extrapolado) | n~5.3x10^5 (ver advertencia metodológica en INFORME_APORTE.md) |

Ver `INFORME_APORTE.md` para la explicación completa de cada métrica y su
interpretación.

## Procedencia del código (trazabilidad)

- **single_include/bmssp.hpp**: librería oficial, sin modificar, de
  lcs147/bmssp (https://github.com/lcs147/bmssp) (mismos autores del paper
  arXiv:2511.03007 citado en el artículo).
- **experiments_original.cpp**: código del proyecto original
  (215326-hub/BMSSP-vs-DIJKSTRA, https://github.com/215326-hub/BMSSP-vs-DIJKSTRA),
  incluido solo como referencia -- de aquí se copiaron literalmente el generador
  de grafos y la fórmula de semilla para que los grafos fueran idénticos a los
  del artículo. No se ejecuta directamente en este paquete.
- **run_one.cpp, run_all.py, analyze.py, analyze_exp2.py**: escritos
  específicamente para este aporte (instrumentación de memoria pico y memoria
  por estructura de datos).

## Autores

Franklin Gilberto Mamani Condori -- Universidad Nacional de San Antonio Abad
del Cusco (UNSAAC)
